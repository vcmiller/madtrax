﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace SBR {
    public class EditClassAndFieldsAttribute : PropertyAttribute {
    }
}